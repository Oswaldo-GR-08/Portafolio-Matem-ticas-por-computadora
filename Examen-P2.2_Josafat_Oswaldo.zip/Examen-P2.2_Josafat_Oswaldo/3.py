import math

a = 500 
tiempos = [9, 10, 11]
alphas_deg = [54.80, 54.06, 53.34]
betas_deg = [65.59, 64.59, 63.62]

x_coords = []
y_coords = []

for i in range(len(tiempos)):
    # Convertir a radianes
    alpha = math.radians(alphas_deg[i])
    beta = math.radians(betas_deg[i])
    
    denominador = math.tan(beta) - math.tan(alpha)
    x = a * (math.tan(beta) / denominador)
    y = a * (math.tan(alpha) * math.tan(beta) / denominador)
    
    x_coords.append(x)
    y_coords.append(y)


h = 1.0

vx = (x_coords[2] - x_coords[0]) / (2 * h)
vy = (y_coords[2] - y_coords[0]) / (2 * h)

rapidez = math.sqrt(vx**2 + vy**2)
angulo_ascenso_rad = math.atan(vy / vx)
angulo_ascenso_deg = math.degrees(angulo_ascenso_rad)

print("--- Resultados del Cálculo Numérico ---")
print(f"Posición (x, y) en t=10s: ({x_coords[1]:.2f}, {y_coords[1]:.2f})")
print(f"Velocidad vx: {vx:.2f} m/s")
print(f"Velocidad vy: {vy:.2f} m/s")
print(f"Rapidez total (v): {rapidez:.2f} m/s")
print(f"Ángulo de ascenso (gamma): {angulo_ascenso_deg:.2f}°")