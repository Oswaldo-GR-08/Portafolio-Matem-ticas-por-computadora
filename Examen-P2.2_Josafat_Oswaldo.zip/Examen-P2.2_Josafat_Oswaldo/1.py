import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline
 
# Datos de la Tabla I
t_data = np.array([0.0, 0.1, 0.25, 0.5, 0.75, 1.0, 1.41, 2.12, 2.83, 4.0, 5.0])
y_data = np.array([0.0000, 0.4292, 2.1162, 5.6133, 8.3122, 9.7900, 10.4153, 10.0860, 9.9827, 10.0004, 10.0001])
 
# Función real
def y_real(t):
    return 10 * (1 - np.exp(-2.25*t) * (np.cos(2.222*t) + 1.0126*np.sin(2.222*t)))
 
# 1. Implementación del Spline Cúbico Natural
cs = CubicSpline(t_data, y_data, bc_type='natural')
 
# Imprimir polinomios de los primeros dos intervalos
print("Coeficientes S_[0.0, 0.1]:", cs.c[:, 0])
print("Coeficientes S_[0.1, 0.25]:", cs.c[:, 1])
 
# 2. Interpolación y Métricas en t = 1.3
t_eval = 1.3
y_int_1_3 = cs(t_eval)
y_real_1_3 = y_real(t_eval)
e_abs = abs(y_real_1_3 - y_int_1_3)
e_rel = e_abs / abs(y_real_1_3)
 
print(f"\ny_real(1.3) = {y_real_1_3:.4f}")
print(f"y_int(1.3) = {y_int_1_3:.4f}")
print(f"Error absoluto (e) = {e_abs:.4f}")
print(f"Error relativo (er) = {e_rel:.4f}")
 
# 3. MSE (Error Cuadrático Medio)
n_mse = 200
t_mse = np.linspace(0, 5, n_mse)
mse = np.sum((y_real(t_mse) - cs(t_mse))**2) / n_mse
print(f"\nMSE = {mse:.6e}")
 
# 4. Comparación Gráfica
t_plot = np.linspace(0, 15, 500)
plt.figure(figsize=(10, 5))
plt.plot(t_plot, y_real(t_plot), 'r-', label='Función Real')
plt.plot(t_plot, cs(t_plot), 'b--', label='Spline Cúbico Interpolado')
plt.xlim(0, 15)
plt.legend()
plt.grid()
plt.title("Respuesta RLC vs Spline Cúbico")
plt.xlabel("Tiempo (s)")
plt.ylabel("Amplitud y(t)")
plt.show()